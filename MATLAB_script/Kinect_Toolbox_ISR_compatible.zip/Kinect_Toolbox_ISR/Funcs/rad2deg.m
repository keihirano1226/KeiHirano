

function [deg] = rad2deg(rad)

deg = rad*180/pi;

