In order to add automatic corner extraction functionality to the Kinect Calibration Toolbox,
please add all files in this folder into the [kinect_toolbox_root]/autoCornerFinder diretory.
The executables use code from the openCv image processing library, developped by Intel and
then distributed unter the GNU general public licence, see the licence file.

Note: these files originally obtained from the ocamCalib Matlab toolbox.