import numpy as np
import random
#A = np.array([[55,55,0,15],[55,55,0,15],[0,0,0,0],[15,15,0,3]])
X = list()
Y = list()
#B = np.linalg.inv(A)
B = np.linalg.det(A)
print(A)
